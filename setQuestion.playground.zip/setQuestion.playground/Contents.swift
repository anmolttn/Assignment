import UIKit

let houseAnimals: Set = ["Dog", "Cat"]
let farmAnimals : Set = ["cow", "Hen", "Sheep", "Dog", "Cat"]
let cityAnimals : Set = ["Bird", "Rat"]


// 1. Determine whether the set of house animals is a subset of farm animals.

if houseAnimals .isSubset(of: farmAnimals) == true{
        print("Yes ! houseAnimals is subset of farmAnimals")
}
else{
    print("Sorry !")
}


//2. Determine whether the set of farm animals is a superset of house animals.
if farmAnimals.isSuperset(of: houseAnimals){
    print("Yes ! farmAnimals is superset of houseAnimals")
}
else{
        print("Sorry !")
}

//3. Determine if the set of farm animals is disjoint with city animals.
if farmAnimals.isDisjoint(with: cityAnimals){
    print("Yes ! farmAnimal is disjoint with cityAnimal")
}
else{
        print("Sorry !")
}

//4. Create a set that only contains farm animals that are not also house animals.
let a = farmAnimals.subtracting(houseAnimals)

print(a)


//5. Create a set that contains all the animals from all sets.
var allAnimal : Set = houseAnimals

allAnimal.formUnion(farmAnimals)
allAnimal.formUnion(cityAnimals)
print(allAnimal)
