import UIKit
//1.What is subscript ? Write down the declaration syntax.


//Subscripts are used to access information from a collection, sequence and a list in Classes, Structures and Enumerations without using a method.

//Syntax
class abc{
subscript(index: Int) -> Int {
    get {
        
        // Return an appropriate subscript value here.
        return 0
        }
    set(newValue) {
        // definition are writeen here
        }
    }
}


//2. Create a simple subscript that outputs true if a string contains a substring and false otherwise.


extension String{
    subscript(para1 : String) -> Bool{
        get{
            let stringValue = self.range(of: para1)
            return !stringValue!.isEmpty
        }
    }
}
var checkValue = "Welcome to To The New"

checkValue["Welcome"]
