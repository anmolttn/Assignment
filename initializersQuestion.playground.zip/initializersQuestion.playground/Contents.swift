import UIKit
// 1. Implement the parameterised initialisation with class or struct.


struct Person {
 
    var firstName: String
    var lastName: String
 
    init(firstName : String, lastName : String) {
        self.firstName = firstName
        self.lastName = lastName
    }
}
var obj = Person(firstName: "Anmol", lastName: "Chauhan")


//2.Write all the Rules of initialiser in Inheritance
//a> A designated initializer should call the designated initializer from its immediate superclass
//b>. A convience initializer should ultimately call a designated initializer
//c>. A convenience initializer should call another initializer from the same class.



//3. Using convenience Initializers, write-down the Initializers for MOVIE class having basic attributes like title, author, publish_date, etc

class Movie{
    var moviTitle : String
    var movieAauthor : String
    var moviePublish_Date : String
    
    init(titleForMovie : String, authorOfTheMovie : String, publishDateOfMovie : String) {
        self.moviTitle = titleForMovie
        self.movieAauthor = authorOfTheMovie
        self.moviePublish_Date = publishDateOfMovie
    }
    convenience init(authorInConvenience : String) {
        
        let movieNameInConvenience = "DDLJ"
        let publishDateInConvience = "19 October 1995"
        
        self.init(titleForMovie : movieNameInConvenience, authorOfTheMovie : authorInConvenience,publishDateOfMovie : publishDateInConvience)
    }
    
    
}


// 4. Declare a structure which can demonstrate the throwable failable Initializer

enum movieName : Error {
    case emptyString
}
struct NamesOfMovie{
    var name : String
    init?(name: String?) throws {
        guard let name = name
            else {
                throw movieName.emptyString
        }
        self.name = name
    }
}
