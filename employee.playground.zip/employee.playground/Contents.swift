/* Create a employee personal information structure and employee professional structure

the properties for personal :
employeeID
name
country(america,india,britain,japan,china)
address
hobbies(optional)*/

//Persoanl details of employee
struct EmpPersonalInfo {
    var empID:Int
    var empName:String
    var empCountry:String
    var empAddress:String
    var empHobbies:String?
}

////Professional details of employee
struct EmpProfessionalInfo {
    var empID:Int
    var empName:String
    var empDepartment:String
    var empbranch:String
    var empExperience:String
}
//Third structure of employee
struct ThirdEmployee{
    var empID:Int
    var empName:String
    var empCountry:String
    var empAddress:String
    var empHobbies:String?
    var empDepartment:String
    var empbranch:String
    var empExperience:String
    
}
//array of object of ThirdEmployee
var empObj : [ThirdEmployee] = []


//array of object of EmpPersoanalInfo
//Data insertion
var e1 : [EmpPersonalInfo]=[EmpPersonalInfo(empID: 100, empName: "Anmol", empCountry: "India", empAddress: "Noida", empHobbies: "cricket")]
e1.insert(EmpPersonalInfo(empID: 101, empName: "Rishi", empCountry: "India", empAddress: "Delhi"), at: 1)
e1.insert(EmpPersonalInfo(empID: 102, empName: "John", empCountry: "America", empAddress: "New York", empHobbies: "Readng"), at: 2)
e1.insert(EmpPersonalInfo(empID: 103, empName: "Shanu", empCountry: "Britain", empAddress: "London"), at: 3)
e1.insert(EmpPersonalInfo(empID: 104, empName: "Shivam", empCountry: "Japan", empAddress: "Tokyo"), at: 4)


//array of object of EmpProfessionalInfo
var e2 : [EmpProfessionalInfo] = []


//Data insertion
e2.insert(EmpProfessionalInfo(empID: 100, empName: "Anmol", empDepartment: "iOS", empbranch: "India", empExperience: "5 years"), at: 0)
e2.insert(EmpProfessionalInfo(empID: 101, empName: "Rishi", empDepartment: "Android", empbranch: "America", empExperience: "2 years"), at: 1)
e2.insert(EmpProfessionalInfo(empID: 102, empName: "John", empDepartment: "jvm", empbranch: "japan", empExperience: "10 years"), at: 2)
e2.insert(EmpProfessionalInfo(empID: 103, empName: "Shanu", empDepartment: "web", empbranch: "Britian", empExperience: "4 years"), at: 3)
e2.insert(EmpProfessionalInfo(empID: 104, empName: "Shivam", empDepartment: "Android", empbranch: "Japan", empExperience: "8 years"), at: 4)


// 1. create a third employee structure that contains the information from both based on common id.

for indexFirst in e1{
    for indexSecond in e2 {
        if indexFirst.empID == indexSecond.empID {
            empObj.append(ThirdEmployee(empID: indexFirst.empID, empName: indexFirst.empName, empCountry: indexFirst.empCountry, empAddress: indexFirst.empAddress, empHobbies: indexFirst.empHobbies, empDepartment: indexSecond.empDepartment, empbranch: indexSecond.empbranch, empExperience: indexSecond.empExperience))
        }
    }
}
print(empObj)



// 2.write a function that takes the two structure and give me list of all the employee that live in certain country
func countryName(country : String){
    print("\n Employee in the \(country) \n")
    for index in empObj{
        if country == index.empCountry {
            print(index.empName)
            }
        }
    }
countryName(country: "India")
countryName(country: "America")
countryName(country: "Britain")
countryName(country: "Japan")



//3.  write a function that give me list of all the employee that live in certain department
func department(department : String){
    print("\n Employee in the \(department) department \n")
    for index in empObj {
        if department == index.empDepartment {
            print(index.empID)
        }
    }
}
department(department: "Android")
department(department: "jvm")
department(department: "iOS")
department(department: "web")




//4.  write a function that give me list of all the employee that live in same country and work in the same branch.
func sameBranchAndCountry(country : String, branch : String){
    for index in empObj{
        if index.empCountry == index.empbranch {
            print("\n",index.empID)
        }
    }
}
sameBranchAndCountry(country: "", branch: "")



//5.  write a function that return me list of all the employee name that has a hobby and with their experience .
func havehobbyWithExperience(hobby : String, experience : String){
    for index in empObj{
        if index.empHobbies != nil{
            print(index.empHobbies, ".This employee have experience of " ,index.empExperience)
        }
    }
}
havehobbyWithExperience(hobby: "", experience: "")




//6.  write a function that return me list of all the employee name that starts with any “S”
func nameStartWithS (name : String){
    for index in empObj{
        if index.empName[index.empName.startIndex] == "S" {
            print("\n", index.empName)
        }
}
}
nameStartWithS(name: "")
