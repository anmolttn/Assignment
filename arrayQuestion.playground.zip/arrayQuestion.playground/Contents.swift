import UIKit



// 1. Create an array containing the 5 different integer values. Write are at least 4 ways to do this

//first way to create an array
var arr1 = [1,2,3,4,5]
print(arr1)

//second way to create an array
var arr2 : [Int] = [1,2,3,4,5]
print(arr2)

//third way to create an array
var arr3 = [Int](repeating: 0, count: 5)
print(arr3)

//fourth way to create an array
var arr4 = [Int]()
arr4.append(1)
arr4.append(2)
arr4.append(3)
arr4.append(4)
arr4.append(5)
print(arr4)


// 2. Create an immutable array containing 5 city names.
let cityArray = ["Bijnor","Delhi","Noida","Mumbai","Kanpur"]
print(cityArray)


// 3. Create an array with city 5 city names. Later add other names like Canada, Switzerland, Spain to the end of the array in at least 2 possible ways.
var mutableCityArray = ["Bijnor","Delhi","Noida","Mumbai","Kanpur"]
print(mutableCityArray)

// first way to add the value in the array at the end
mutableCityArray.append("Canada")
mutableCityArray.append("Switzerland")
print(mutableCityArray)

//second way to add the value in the array at the end
mutableCityArray.insert("Spain", at: 7)
mutableCityArray.insert("Chennai", at: 8)

print(mutableCityArray)



// 4.Create an array with values 14, 18, 15, 16, 23, 52, 95. Replace the values 24 & 48 at 2nd & 4th index of array
var arr5 = [14, 18, 15, 16, 23, 52, 95]
print(arr5)

arr5[2]=24
arr5[4]=48

print(arr5)
